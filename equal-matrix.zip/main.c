/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
int main()
{
    int *a[3],*b[3] ,n,m,p,q,x;
    printf("enter the order of  matrix 1 : ");
    scanf("%d %d",&m,&n);
    printf("enter the order of matrix 2 : ");
    scanf("%d%d",&p,&q);
    for(int i=0;i<m;i++)
     a[i]=(int*)malloc(n*sizeof(int));
    for(int i=0;i<p;i++)
     b[i]=(int*)malloc(q*sizeof(int));
    printf("enter the elements of matrix 1 : ");
    for(int i=0;i<m; i++)
     for(int j=0;j<n;j++)
      scanf("%d",a[i]+j);
    printf("enter the elements of matrix 2 : ");
    for (int i=0;i<p;i++)
     for (int j=0;j<q;j++)
       scanf("%d",b[i]+j);
    if(n!=q || m!=p) {
        x=0;
    }
    else{
      for (int i =0;i<m ;i++)
        for(int j=0;j<n;j++)
        if(*(a[i]+j) != *(b[i]+j) )
           {x=0;}
        else
           { x=1;}
    }
    
    if (x==1)
      printf("equal matrices");
    else 
      printf("not equal matrices");
    return 0;
}